#include <stdio.h>      /* printf, sprintf */
#include <stdlib.h>     /* exit, atoi, malloc, free */
#include <unistd.h>     /* read, write, close */
#include <string.h>     /* memcpy, memset */
#include <sys/socket.h> /* socket, connect */
#include <netinet/in.h> /* struct sockaddr_in, struct sockaddr */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"
#include "parson/parson.h"

#define HOST "63.32.125.183"
#define PORT 8081
#define MAX_TOKENS 100

char **cookies;
int cookies_len = 0;
char **tokens;
int token_size = 0;

int connect_to_server() {
    // Obtinem un socket TCP pentru conectarea la server
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    DIE(sockfd < 0, "socket");

    // Completăm in serv_addr adresa serverului, familia de adrese si portul
    // pentru conectare
    struct sockaddr_in serv_addr;
    socklen_t socket_len = sizeof(struct sockaddr_in);

    memset(&serv_addr, 0, socket_len);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    int rc = inet_pton(AF_INET, HOST, &serv_addr.sin_addr.s_addr);
    DIE(rc <= 0, "inet_pton");

    // Ne conectăm la server
    rc = connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    DIE(rc < 0, "connect");

    printf("Connected to server\n");

    return sockfd;

}

void GET(char url[], int has_cookies, char **response) {

    int sockfd = connect_to_server();
    char *message = calloc(1, LINELEN);

    if (has_cookies == 1) {
        message = compute_get_request(HOST, url, NULL, cookies, cookies_len);
    } else {
        message = compute_get_request(HOST, url, NULL, NULL, 0);
    }

    printf("%s\n", message);

    send_to_server(sockfd, message);
    *response = receive_from_server(sockfd);

    close_connection(sockfd);

}

void POST(char serialized_string[], int len, char url[], char content_type[], int has_cookies, char **response) {

    int sockfd = connect_to_server();
    char *message;

    char **body_data = calloc(len, LINELEN);
    for (int i = 0; i < len; i++) {
        body_data[i] = calloc(1, LINELEN);
        strcpy(body_data[i], serialized_string);
    }
    int body_data_fields_count = len;
    if (has_cookies == 0) {
        message = compute_post_request(HOST, url, content_type, body_data, body_data_fields_count, NULL, 0);
    } else {
        message = compute_post_request(HOST, url, content_type, body_data, body_data_fields_count, cookies, cookies_len);
    }
    printf("Message sent: %s\n ", message);
    send_to_server(sockfd, message);
    *response = receive_from_server(sockfd);

    close_connection(sockfd);
}

void login_request(char admin_username[], char username[], char password[]) {

    JSON_Value *root_value = json_value_init_object();
    JSON_Object *root_object = json_value_get_object(root_value);

    json_object_set_string(root_object, "admin_username", admin_username);
    json_object_set_string(root_object, "username", username);
    json_object_set_string(root_object, "password", password);

    char *serialized_string = NULL;
    serialized_string = json_serialize_to_string_pretty(root_value);

    char *response = calloc(1, LINELEN);

    POST(serialized_string, 1,  "/api/v1/tema/user/login", "application/json", 0, &response);

    char *p = strstr(response, "Set-Cookie: ");
    if (p) {
        p = p + strlen("Set-Cookie: ");
        int len = 0;
        while(*p != ';') {
            cookies[cookies_len][len] = *p;
            p++;
            len++;
        }
        cookies[cookies_len][len] = '\0';
        cookies_len++;
    }

    if (strstr(response, "HTTP/1.1 2")) {
        printf("SUCCESS: Autentificare reușită \n");
    } else {
        printf("ERROR: \n");
    }

    json_free_serialized_string(serialized_string);
    json_value_free(root_value);
}

void login_admin(char username[], char password[]) {

    JSON_Value *root_value = json_value_init_object();
    JSON_Object *root_object = json_value_get_object(root_value);

    json_object_set_string(root_object, "username", username);
    json_object_set_string(root_object, "password", password);

    char *serialized_string = NULL;
    serialized_string = json_serialize_to_string_pretty(root_value);

    char *response = calloc(1, LINELEN);

    POST(serialized_string, 1,  "/api/v1/tema/admin/login", "application/json", 0, &response);

    char *p = strstr(response, "Set-Cookie: ");
    if (p) {
        p = p + strlen("Set-Cookie: ");
        int len = 0;
        while(*p != ';') {
            cookies[cookies_len][len] = *p;
            p++;
            len++;
        }
        cookies[cookies_len][len] = '\0';
        cookies_len++;
    }

    if (strstr(response, "HTTP/1.1 2")) {
        printf("SUCCESS: Admin autentificat cu succes \n");
    } else {
        printf("ERROR: ");
    }

    json_free_serialized_string(serialized_string);
    json_value_free(root_value);
}

void add_user(char username[], char password[]) {

    JSON_Value *root_value = json_value_init_object();
    JSON_Object *root_object = json_value_get_object(root_value);

    json_object_set_string(root_object, "username", username);
    json_object_set_string(root_object, "password", password);

    char *serialized_string = NULL;
    serialized_string = json_serialize_to_string_pretty(root_value);

    char *response = calloc(1, LINELEN);

    POST(serialized_string, 1,  "/api/v1/tema/admin/users", "application/json", 1, &response);

    if (strstr(response, "HTTP/1.1 2")) {
        printf("SUCCESS: Utilizator adăugat cu succes \n");
    } else {
        printf("ERROR: ");
    }

    json_free_serialized_string(serialized_string);
    json_value_free(root_value);
}

void parse_users(const char *json_string) {

    JSON_Value *root_value = json_parse_string(json_string);
    JSON_Object *root_object = json_value_get_object(root_value);

    JSON_Array *users = json_object_get_array(root_object, "users");
    size_t count = json_array_get_count(users);

    for (size_t i = 0; i < count; i++) {
        JSON_Object *user = json_array_get_object(users, i);

        int id = (int)json_object_get_number(user, "id");
        const char *username = json_object_get_string(user, "username");
        const char *password = json_object_get_string(user, "password");

        printf("#%zu %s %s\n", id, username, password);
    }

    json_value_free(root_value);
}

void get_users() {

    char *response = calloc(1, LINELEN);
    GET("/api/v1/tema/admin/users", 1, &response);

    if (strstr(response, "HTTP/1.1 2")) {
        parse_users(strstr(response, "{\"users\""));
        printf("SUCCES: \n");
    } else {
        printf("ERROR: ");
    }
}

void logout_admin() {

    char *response = calloc(1, LINELEN);
    GET("/api/v1/tema/admin/logout", 1, &response);

    printf("%s\n", response);

    if (strstr(response, "HTTP/1.1 2")) {
        printf("SUCCES: Admin delogat\n");

        cookies_len = 0;

        for (int i = 0; i < LINELEN; i++) {
            free(cookies[i]);
        }
        free(cookies);

        cookies = calloc(LINELEN, sizeof(char *));
        for (int i = 0; i < LINELEN; i++) {
            cookies[i] = calloc(1, LINELEN);
        }

    } else {
        printf("ERROR: ");
    }
}

void get_acces() {

    char *response = calloc(1, LINELEN);
    GET("/api/v1/tema/library/access", 1, &response);

    printf("%s\n", response);

    if (strstr(response, "HTTP/1.1 2")) {

        char *p = strstr(response, "{\"token\"");
        p = p + 9;
        int i = 0;
        while (*p != '}') {
            tokens[token_size][i] = *p;
            p++;
            i++;
        }
        tokens[token_size][i] = '\0';
        token_size++;

        printf("SUCCES: Token JWT primit\n");
    } else {
        printf("ERROR : Utilizator neautorizat \n");
    }

}

void logout() {

    char *response = calloc(1, LINELEN);
    GET("/api/v1/tema/library/access", 1, &response);

    printf("%s\n", response);

    if (strstr(response, "HTTP/1.1 2")) {
        printf("SUCCES: Utilizator delogat\n");

        cookies_len = 0;

        for (int i = 0; i < LINELEN; i++) {
            free(cookies[i]);
        }
        free(cookies);

        cookies = calloc(LINELEN, sizeof(char *));
        for (int i = 0; i < LINELEN; i++) {
            cookies[i] = calloc(1, LINELEN);
        }

    } else {
        printf("ERROR: ");
    }

}

int main(int argc, char *argv[])
{

    char *message;
    char *response;
    int sockfd = connect_to_server();

    cookies = calloc(LINELEN, sizeof(char *));
    for (int i = 0; i < LINELEN; i++) {
        cookies[i] = calloc(1, LINELEN);
    }

    tokens = calloc(MAX_TOKENS, sizeof(char *));
    for (int i = 0; i < MAX_TOKENS; i++) {
        tokens[i] = calloc(1, LINELEN);
    }

    while(1) {
        char line[LINELEN];
        fgets(line, LINELEN, stdin);
        size_t len = strlen(line);
        if (len > 0 && line[len-1] == '\n') {
            line[len-1] = '\0';
        }
        printf("Linie citita: %s\n", line);
        if (strncmp(line, "login_admin", 11) == 0) {

            char username[LINELEN], password[LINELEN];
            printf("username=");
            fgets(username, LINELEN, stdin);
            size_t len = strlen(username);
            if (len > 0 && username[len-1] == '\n') {
                username[len-1] = '\0';
            }
            printf("password=");
            fgets(password, LINELEN, stdin);
            len = strlen(password);
            if (len > 0 && password[len-1] == '\n') {
                password[len-1] = '\0';
            }
            printf("Username citit: %s\n", username);
            printf("Parola citita: %s\n", password);
            login_admin(username, password);

        } else if (strncmp(line, "login", 5) == 0) {

            char admin_username[LINELEN], username[LINELEN], password[LINELEN];
            printf("admin_username=");
            fgets(admin_username, LINELEN, stdin);
            admin_username[strlen(admin_username) - 1] = '\0';
            printf("username=");
            fgets(username, LINELEN, stdin);
            username[strlen(username) - 1] = '\0';
            printf("password=");
            fgets(password, LINELEN, stdin);
            password[strlen(password) - 1] = '\0';
            login_request(admin_username, username, password);

        } else if (strncmp(line, "add_user", 8) == 0) {

            char username[LINELEN], password[LINELEN];
            printf("username=");
            fgets(username, LINELEN, stdin);
            size_t len = strlen(username);
            if (len > 0 && username[len-1] == '\n') {
                username[len-1] = '\0';
            }
            printf("password=");
            fgets(password, LINELEN, stdin);
            len = strlen(password);
            if (len > 0 && password[len-1] == '\n') {
                password[len-1] = '\0';
            }
            printf("Username citit: %s\n", username);
            printf("Parola citita: %s\n", password);
            add_user(username, password);

        } else if (strncmp( line, "get_users", 9) == 0){
            get_users();

        } else if (strncmp(line, "logout_admin", 12) == 0) {
            logout_admin();

        } else if (strncmp(line, "get_acces", 9) == 0) {
            get_acces();

        } else if (strncmp(line, "logout", 7) == 0) {
            logout();

        } else if (strcmp("exit", line)) {
            break;
        }
    }

    return 0;
}
